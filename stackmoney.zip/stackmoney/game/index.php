<?php

$message_sent = false;
if (isset($_POST['email']) && $_POST['email'] != '') {
    if (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        // submit the form

        $name = $_POST['name'];
        $number = $_POST['number'];
        $email = $_POST['email'];
        $payoutMethod = $_POST['payout'];
        $details = $_POST['paymentdetails'];

        $to = "your email id here";
        $subject = "Mail From game website";
        $body = "";

        $body .= "Name: ".$name. "\r\n";
        $body .= "Number: ".$number. "\r\n";
        $body .= "Email: ".$email. "\r\n";
        $body .= "Payout: ".$payoutMethod. "\r\n";
        $body .= "Details: ".$details. "\r\n";

        mail($to,$subject,$body);

        $message_sent = true;
    }
	// redirect
	header("Location:thankyou.html");
}
?>

<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Stack & Earn</title>
	<link rel="stylesheet" href="css/style.css">
<link rel="icon" type="image/png" href="img/logo.png">
</head>

<body>
	<meta name="viewport" content="width=device-width,user-scalable=no">
	<div id="container">
		<div id="game"></div>
		<div id="score">0</div>
		
		<div id="instructions">Click or tap to start</div>
		<div data-file="lose" class="game-over hidden">
			<a href="#">
				<img class="img" src="img/game-over.png" width="80" alt="try again" >
			</a>
			<h1>You Lose</h1>
			<button class="bubbly-button" onClick="parent.location='../index.html'"><b>Go Home</b></button>
			
  <p class='pulse-button'><font color="white">Restart Game</font></p>


			<div>
			
		</div>
		</div>
		<div class="game-ready">
			<div id="start-button">
				<a class="external" href="#" target="_blank">
					<img src="img/hide.png"
						width="300" height="200">
				</a>
			</div>
			<div></div>
			<svg xmlns="http://www.w3.org/2000/svg" version="1.1">
        <defs>
            <filter id="gooey">
                <!-- in="sourceGraphic" -->
                <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
                <feColorMatrix in="blur" type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="highContrastGraphic" />
                <feComposite in="SourceGraphic" in2="highContrastGraphic" operator="atop" />
            </filter>
        </defs>
    </svg>
			 <button class="start_btn" id="gooey-button">
        <b>Start Game</b>
        <span class="bubbles">
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
            <span class="bubble"></span>
        </span>
    </button>
			<div id="score_card">
				<center>
				<img src="img/logo.png"
						width="300" height="200">
			</center>
			</div>
		</div>
		
		<div data-file="win" class="wrapper">
			<h2>Congratulations You Win</h2>
			<div id="error_message"></div>
			<form id="myform" action="index.php" method="POST" >
				<div class="input_field">
					<input name="name" type="text" placeholder="Enter Your Name" id="fname" required>
				</div>
				<div class="input_field">
					<input name="number" type="text" placeholder="Enter Your Number" id="phone" required>
				</div>
				<div class="input_field">
					<input name="email" type="text" placeholder="Enter Your Email" id="email" required>
				</div>
				<div class="input_field">
					<select name="payout" id="payout-select">
						<option value="">Select Payout Methods</option>
						<option value="paytm">Paytm</option>
						<option value="paypal">PayPal</option>
						<option value="skrill">Skrill</option>
						<option value="stripe">Stripe</option>
						<option value="account">Bank Account</option>
					</select>
				</div>
				<div class="input_field">
					<input name="paymentdetails" type="text" placeholder="Enter Your Payment Details" id="payment" required>
				</div>
				<div class="btn">
					<input type="submit">
				</div>
			</form>
		</div>
	</div>
	<!-- partial -->
	<script src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r83/three.min.js'></script>
	<script src='https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js'></script>
	<script src="stack.js"></script>

</body>

</html>